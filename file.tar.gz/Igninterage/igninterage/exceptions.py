class LoginError(Exception):
    """Impossivel logar"""
    pass


class NotXenforoPage(Exception):
    """Elementos de uma pagina xenforo nao encontrados"""
    pass
